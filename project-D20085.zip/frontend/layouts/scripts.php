    <script src="/project-D20085/assets/vendor/jQuery/jquery.min.js"></script>
    <script src="/project-D20085/assets/vendor/popperjs/popper.min.js"></script>
    <script src="/project-D20085/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="/project-D20085/assets/frontend/js/app.js"></script>
    <script src="/project-D20085/assets/vendor/vue/vue.js"></script>