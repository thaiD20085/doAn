<title><?= $PAGE_TITLE; ?></title>
<?php include_once(__DIR__ . '/meta.php'); ?>
<link rel="icon" href="/project-D20085/assets/frontend/img/logo/logo.png" type="image/gif" sizes="16x16">
<?php include_once(__DIR__ . '/styles.php'); ?>