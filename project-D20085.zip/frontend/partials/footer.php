<footer>
    <div class="container-fluid" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 d-md-none">
                    <ul class="list-nonestyle d-flex justify-content-center">
                        <ul class="list-nonestyle">
                            <li class="h3 social">
                                <a href="#"><i class="fa fa-instagram mx-2" ar ia-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter mx-2" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-facebook mx-2" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus mx-2" aria-hidden="true"></i></a>
                            </li>
                        </ul>
                    </ul>
                </div>
                <div class="col-md-3 fcol">
                    <ul class="list-nonestyle">
                        <li id="lhFooter">
                            <i class="fa fa-caret-down d-block d-md-none" style="float: right" aria-hidden="true"></i>
                            <h6 class="font-weight-bolder">Liên hệ</h6>
                        </li>
                        <li>
                            <ul class="list-nonestyle listFooter" id="lhList">
                                <li>
                                    <a href="cel:123123123">123123123</a>
                                </li>
                                <li>
                                    <a href="mal:admin@admin.com">admin@admin.com</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="col-md-3 fcol">
                    <ul class="list-nonestyle">
                        <li id="carFooter">
                            <i class="fa fa-caret-down d-block d-md-none" style="float: right" aria-hidden="true"></i>
                            <h6 class="font-weight-bolder">Linh kiện vi tính</h6>
                        </li>
                        <li>
                            <ul class="list-nonestyle listFooter" id="carList">
                                <li>
                                    <a href="#">Main board</a>
                                </li>
                                <li>
                                    <a href="#">Ram</a>
                                </li>
                                <li>
                                    <a href="#">CPU</a>
                                </li>
                                <li>
                                    <a href="#">VGA</a>
                                </li>
                                <li>
                                    <a href="#">Bộ nhớ</a>
                                </li>
                                <li>
                                    <a href="#">Nguồn</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="col-md-3 fcol">
                    <ul class="list-nonestyle">
                        <li id="bikeFooter">
                            <i class="fa fa-caret-down d-block d-md-none" style="float: right" aria-hidden="true"></i>
                            <h6 class="font-weight-bolder">Thiết bị ngoại vi</h6>
                        </li>
                        <li>
                            <ul class="list-nonestyle listFooter" id="bikeList">
                                <li>
                                    <a href="#">Chuột</a>
                                </li>
                                <li>
                                    <a href="#">Bàn phím</a>
                                </li>
                                <li>
                                    <a href="#">Màn hình</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="col-md-3 fcol d-none d-md-block">
                    <ul class="list-nonestyle">
                        <h6 class="font-weight-bolder">Social</h6>
                        <ul class="list-nonestyle listFooter">
                            <li class="h4 social">
                                <a href="#"><i class="fa fa-instagram mx-1" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter mx-1" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-facebook mx-1" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus mx-1" aria-hidden="true"></i></a>
                            </li>
                        </ul>
                    </ul>
                    <ul class="list-nonestyle">
                        <h6 class="font-weight-bolder">Phương thức thanh toán</h6>
                        <li class="ml-3" id="thanhToan">
                            <img src="/project-D20085/assets/frontend/img/bank/visa.svg" />
                            <img src="/project-D20085/assets/frontend/img/bank/mastercard.svg" />
                            <img src="/project-D20085/assets/frontend/img/bank/jcb.svg" />
                            <br />
                            <img src="/project-D20085/assets/frontend/img/bank/cash.svg" />
                            <img src="/project-D20085/assets/frontend/img/bank/internet-banking.svg" />
                            <img src="/project-D20085/assets/frontend/img/bank/installment.svg" />
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-light">
        <div class="container">
            <div class="row">
                <div class="col-12 text-right">
                    <ul class="list-nonestyle copyright-content">
                        <li>
                            <a href="#">Chính sách Bảo mật</a>
                        </li>
                        <li>
                            <a href="#">Điều Khoản và Điều Kiện</a>
                        </li>
                        <li>
                            <a href="#">Thông tin công ty</a>
                        </li>
                        <li>
                            Bản quyền bởi &copy;<a href="index.html">Linh kiện vi tính</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>