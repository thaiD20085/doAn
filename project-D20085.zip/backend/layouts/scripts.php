<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="/hocPHP-CP20SCF26/assets/vendor/jquery/jquery.min.js"></script>
<script src="/hocPHP-CP20SCF26/assets/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Thư viện Jquery validation -->
<script src="/hocPHP-CP20SCF26/assets/vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="/hocPHP-CP20SCF26/assets/vendor/jquery-validation/localization/messages_vi.min.js"></script>