<!-- Bootstrap CSS -->
<link rel="stylesheet" href="/project-D20085/assets/vendor/bootstrap/css/bootstrap.min.css" type="text/css" />
<!-- Font awesome -->
<link rel="stylesheet" href="/project-D20085/assets/vendor/font-awesome/css/font-awesome.min.css" type="text/css" />

<!-- Custom css - Các file css do chúng ta tự viết -->
<link rel="stylesheet" href="/project-D20085/backend/css/style.css" type="text/css" />