<nav class="navbar navbar-dark bg-dark shadow">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="/project-D20085/backend/pages/dashboard.php">Quản lý</a>
  <ul class="navbar-nav px-3 mr-auto">
    <li class="nav-item text-nowrap">
      <a class="nav-link" href="/project-D20085/backend/pages/dashboard.php">Bảng tin</a>
    </li>
  </ul>
</nav>